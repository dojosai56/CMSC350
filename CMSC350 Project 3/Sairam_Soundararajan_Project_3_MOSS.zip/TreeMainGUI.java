/**
 * Name: Sairam Soundararajan
 * Date: 2-22-21
 * Course: CMSC350: Data Structures and Analysis
 * Project 3
 * Description: The TreeMainGUI class contains all the graphical components using JavaFX and components from the BinaryTree class and InvalidTreeSyntax in order to perform the necessary operations of the Binary Tree
 */
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class TreeMainGUI extends Application {
    private Button makeTreeBtn, isBalancedBtn, isFullBtn, isProperBtn,
            heightBtn, nodesBtn, inOrderBtn;
    private Label enterTreeLbl, outputLbl;
    private TextField enterTreeTxtField, outputTxtField;
    private HBox row1_hbox, row2_hbox, row3_hbox;
    private VBox vbox;

    //variable for BinaryTree
    private BinaryTree binaryTree;



    public static void main(String[] args)
    {
        launch(args);
    }


    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("Binary Tree Categorizor");
        // create components for row1 hbox
        enterTreeLbl = new Label("Enter Tree");

        enterTreeTxtField = new TextField();
        enterTreeTxtField.setPrefColumnCount(50);

        row1_hbox = new HBox();
        row1_hbox.getChildren().addAll(enterTreeLbl, enterTreeTxtField);

        /* create components for row2 hbox       */
        makeTreeBtn = new Button("Make Tree");

        isBalancedBtn = new Button("Is Balanced?");

        isFullBtn = new Button("Is Full?");

        isProperBtn = new Button("Is Proper?");

        heightBtn = new Button("Height");

        nodesBtn = new Button("Nodes");

        inOrderBtn = new Button("In Order");

        row2_hbox = new HBox();
        row2_hbox.getChildren().addAll(makeTreeBtn, isBalancedBtn, isFullBtn, isProperBtn,
                heightBtn, nodesBtn, inOrderBtn);

                /* create components for row3 hbox        */

        outputLbl = new Label("Output");

        outputTxtField = new TextField();
        outputTxtField.setEditable(false);

        row3_hbox = new HBox();
        row3_hbox.getChildren().addAll(outputLbl, outputTxtField);

        // add each row hBox to the Vbox
        vbox = new VBox(5);
        vbox.getChildren().addAll(row1_hbox, row2_hbox, row3_hbox);

        addButtonHandlers();

        // create Scene and show it
        Scene scene = new Scene(vbox);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void addButtonHandlers()
    {
        makeTreeBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    binaryTree = new BinaryTree(enterTreeTxtField.getText());
                    outputTxtField.setText("Tree Successfully Created!!");
                } catch(InvalidTreeSyntax ex)
                {
                    showErrorAlertBox(ex.getMessage());
                }
            }
        }
        );

        isBalancedBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if(binaryTree == null) {
                    //display some error
                    showErrorAlertBox("Tree not yet Made!");
                    return;
                }

                if(binaryTree.isBalanced())
                    outputTxtField.setText("Tree is balanced");
                else
                    outputTxtField.setText("Tree is NOT balanced.");

            }
        });

        isFullBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if(binaryTree == null) {
                    //display some error
                    showErrorAlertBox("Tree is not yet made!!");
                    return;
                }

                if(binaryTree.isFull())
                    outputTxtField.setText("Tree is Full!!");
                else
                    outputTxtField.setText("Tree is NOT Full.");

            }
        });

        isProperBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if(binaryTree == null) {
                    //display some error
                    showErrorAlertBox("Tree is not yet made!!");
                    return;
                }

                if(binaryTree.isProper())
                    outputTxtField.setText("Tree is Proper!!");
                else
                    outputTxtField.setText("Tree is NOT Proper.");
            }
        });

        heightBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if(binaryTree == null) {
                    //display some error
                    showErrorAlertBox("Tree is not yet made!!");
                    return;
                }

                outputTxtField.setText("Max tree height is " + binaryTree.height());
            }
        });

        nodesBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if(binaryTree == null) {
                    //display some error
                    showErrorAlertBox("Tree is not yet made!!");
                    return;
                }

                outputTxtField.setText("Number of Nodes in tree is " + binaryTree.amountOfNodes());
            }
        });

        inOrderBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if(binaryTree == null) {
                    //display some error
                    showErrorAlertBox("Tree is not yet made!!");
                    return;
                }

                outputTxtField.setText(binaryTree.inOrder());
            } // handle
        });
    }

    private static void showErrorAlertBox(String msg)
    {
        Alert errorAlert = new Alert(Alert.AlertType.ERROR, msg);
        errorAlert.showAndWait();
    }// show error alert box

}
