/**
 * Name: Sairam Soundararajan
 * Date: 2-22-21
 * Course: CMSC350: Data Structures and Analysis
 * Project 3
 * Description: The InvalidTreeSyntax class is a checked exception that displays an error message
 */
public class InvalidTreeSyntax extends Exception
{
  public InvalidTreeSyntax()
  {
    super("Error! Invalid Tree Syntax!");
  } // default constructor
    public InvalidTreeSyntax(String message)
    {
        super(message);
    }


}
